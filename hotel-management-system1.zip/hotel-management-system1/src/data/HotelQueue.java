package data;

import models.Guest;
import java.util.LinkedList;
import java.util.Queue;

public class HotelQueue {
    private Queue<Guest> guestQueue;
    private int nextGuestId;

    public HotelQueue() {
        guestQueue = new LinkedList<>();
        nextGuestId = 1;
    }

    public boolean enqueue(String name, String email, String phone, String idProof, 
                          int roomNumber, String checkInDate, String checkOutDate) {
        try {
            Guest newGuest = new Guest(nextGuestId++, name, email, phone, idProof, 
                                     roomNumber, checkInDate, checkOutDate, "Checked-In");
            return guestQueue.add(newGuest);
        } catch (Exception e) {
            return false;
        }
    }

    public Guest dequeue() {
        return guestQueue.poll();
    }

    public Guest peek() {
        return guestQueue.peek();
    }

    public boolean addGuest(Guest guest) {
        return guestQueue.add(guest);
    }

    public boolean deleteGuest(int guestId) {
        Queue<Guest> tempQueue = new LinkedList<>();
        boolean found = false;

        while (!guestQueue.isEmpty()) {
            Guest guest = guestQueue.poll();
            if (guest.getGuestId() != guestId) {
                tempQueue.add(guest);
            } else {
                found = true;
            }
        }

        guestQueue = tempQueue;
        return found;
    }

    public boolean updateGuest(int guestId, String name, String email, String phone, 
                              String idProof, int roomNumber, String checkInDate, String checkOutDate) {
        for (Guest guest : guestQueue) {
            if (guest.getGuestId() == guestId) {
                guest.setName(name);
                guest.setEmail(email);
                guest.setPhone(phone);
                guest.setIdProof(idProof);
                guest.setRoomNumber(roomNumber);
                guest.setCheckInDate(checkInDate);
                guest.setCheckOutDate(checkOutDate);
                return true;
            }
        }
        return false;
    }

    public Queue<Guest> getAllGuests() {
        return new LinkedList<>(guestQueue);
    }

    public Guest searchGuest(int guestId) {
        for (Guest guest : guestQueue) {
            if (guest.getGuestId() == guestId) {
                return guest;
            }
        }
        return null;
    }

    public int getQueueSize() {
        return guestQueue.size();
    }

    public boolean isEmpty() {
        return guestQueue.isEmpty();
    }

    public Queue<Guest> getGuestsByStatus(String status) {
        Queue<Guest> filtered = new LinkedList<>();
        for (Guest guest : guestQueue) {
            if (guest.getStatus().equalsIgnoreCase(status)) {
                filtered.add(guest);
            }
        }
        return filtered;
    }
}