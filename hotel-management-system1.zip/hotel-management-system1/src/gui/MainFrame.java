package gui;

import data.HotelQueue;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private HotelQueue hotelQueue;

    public MainFrame() {
        hotelQueue = new HotelQueue();
        initializeFrame();
        setupTabs();
    }

    private void initializeFrame() {
        setTitle("🏨 LUXURY HOTEL MANAGEMENT SYSTEM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1300, 850);
        setLocationRelativeTo(null);
        
        // 🆕 MODERN BLUE BACKGROUND
        getContentPane().setBackground(new Color(230, 240, 255));
    }

    private void setupTabs() {
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        // 🆕 MODERN TAB COLORS
        tabbedPane.setBackground(Color.WHITE);
        tabbedPane.setForeground(new Color(60, 60, 60));

        // Create tabs with new icons and names
        tabbedPane.addTab("📊 DASHBOARD", new DashboardPanel(hotelQueue));
        tabbedPane.addTab("✅ CHECK-IN", new CheckInPanel(hotelQueue));
        tabbedPane.addTab("🚪 CHECK-OUT", new CheckOutPanel(hotelQueue));
        tabbedPane.addTab("🛏️ ROOMS", new RoomManagementPanel(hotelQueue));

        add(tabbedPane);
    }

    public static void main(String[] args) {
        // 🆕 SIMPLE - NO UIManager CODE
        SwingUtilities.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }
}