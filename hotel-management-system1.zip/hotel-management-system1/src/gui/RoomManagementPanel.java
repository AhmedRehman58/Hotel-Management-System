package gui;

import data.HotelQueue;
import gui.styles.Colors;
import models.Guest;
import models.Room;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class RoomManagementPanel extends JPanel {
    private HotelQueue hotelQueue;
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private List<Room> rooms;

    public RoomManagementPanel(HotelQueue hotelQueue) {
        this.hotelQueue = hotelQueue;
        initializeRooms();
        initializePanel();
        refreshRoomTable();
    }

    private void initializeRooms() {
        rooms = new ArrayList<>();
        // BETTER ROOM TYPES WITH DIFFERENT PRICES
        rooms.add(new Room(101, "Standard", 99.99, "WiFi, TV, AC", "Available"));
        rooms.add(new Room(102, "Standard", 99.99, "WiFi, TV, AC", "Available"));
        rooms.add(new Room(103, "Standard", 99.99, "WiFi, TV, AC", "Available"));
        rooms.add(new Room(104, "Deluxe", 149.99, "WiFi, TV, AC, Mini-bar", "Available"));
        rooms.add(new Room(105, "Deluxe", 149.99, "WiFi, TV, AC, Mini-bar", "Available"));
        rooms.add(new Room(106, "Suite", 199.99, "WiFi, TV, AC, Jacuzzi", "Available"));
        rooms.add(new Room(107, "Suite", 199.99, "WiFi, TV, AC, Jacuzzi", "Available"));
        rooms.add(new Room(108, "Premium", 249.99, "WiFi, TV, AC, Kitchen", "Available"));
        rooms.add(new Room(109, "Premium", 249.99, "WiFi, TV, AC, Kitchen", "Available"));
        rooms.add(new Room(110, "Luxury", 299.99, "WiFi, TV, AC, Pool", "Available"));
    }

    private void initializePanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Colors.BACKGROUND_COLOR);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(155, 89, 182));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("🏠 Room Management - 10 Rooms Available");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Room Table
        add(createRoomTablePanel(), BorderLayout.CENTER);

        // Operations Panel
        add(createOperationsPanel(), BorderLayout.SOUTH);
    }

    private JPanel createRoomTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        JLabel tableTitle = new JLabel("Hotel Rooms Inventory - Select from Available Rooms during Check-in");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableTitle.setForeground(Colors.TEXT_COLOR);
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        // Table setup
        String[] columns = {"Room No", "Type", "Price/Night", "Amenities", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        roomTable = new JTable(tableModel);
        roomTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        roomTable.setRowHeight(30);
        roomTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        roomTable.getTableHeader().setBackground(new Color(155, 89, 182));
        roomTable.getTableHeader().setForeground(Color.WHITE);

        // FIXED: Color code room status - SIMPLE VERSION
        roomTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                // FIXED: Safely get status value
                Object statusValue = tableModel.getValueAt(row, 4);
                if (statusValue != null) {
                    String status = statusValue.toString();
                    switch (status) {
                        case "Available":
                            c.setBackground(new Color(220, 255, 220)); // Light Green
                            break;
                        case "Occupied":
                            c.setBackground(new Color(255, 220, 220)); // Light Red
                            break;
                        case "Maintenance":
                            c.setBackground(new Color(255, 255, 200)); // Light Yellow
                            break;
                        default:
                            c.setBackground(Color.WHITE);
                    }
                }
                
                if (isSelected) {
                    c.setBackground(table.getSelectionBackground());
                    c.setForeground(table.getSelectionForeground());
                }
                
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(roomTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182)));

        panel.add(tableTitle, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createOperationsPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        JButton refreshBtn = createButton("🔄 Refresh Rooms", Colors.SECONDARY_COLOR);
        refreshBtn.addActionListener(e -> refreshRoomTable());

        JButton addRoomBtn = createButton("➕ Add Room", Colors.SUCCESS_COLOR);
        addRoomBtn.addActionListener(e -> addRoom());

        JButton updateRoomBtn = createButton("✏️ Update Room", Colors.WARNING_COLOR);
        updateRoomBtn.addActionListener(e -> updateRoom());

        JButton deleteRoomBtn = createButton("🗑️ Delete Room", Colors.ACCENT_COLOR);
        deleteRoomBtn.addActionListener(e -> deleteRoom());

        // SHOW AVAILABLE ROOMS BUTTON
        JButton availableBtn = createButton("📊 Show Available", new Color(0, 150, 136));
        availableBtn.addActionListener(e -> showAvailableRooms());

        panel.add(refreshBtn);
        panel.add(addRoomBtn);
        panel.add(updateRoomBtn);
        panel.add(deleteRoomBtn);
        panel.add(availableBtn);

        return panel;
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        button.setFocusPainted(false);
        return button;
    }

    private void refreshRoomTable() {
        tableModel.setRowCount(0);
        
        // Update room status based on current guests
        updateRoomOccupancy();
        
        for (Room room : rooms) {
            tableModel.addRow(room.toTableRow());
        }
    }

    private void updateRoomOccupancy() {
        // Reset all rooms to available first
        for (Room room : rooms) {
            if (!"Maintenance".equals(room.getStatus())) {
                room.setStatus("Available");
            }
        }

        // Mark occupied rooms based on current guests
        Queue<Guest> guests = hotelQueue.getAllGuests();
        for (Guest guest : guests) {
            int roomNumber = guest.getRoomNumber();
            for (Room room : rooms) {
                if (room.getRoomNumber() == roomNumber) {
                    room.setStatus("Occupied");
                    break;
                }
            }
        }
    }

    // SHOW AVAILABLE ROOMS METHOD
    private void showAvailableRooms() {
        updateRoomOccupancy();
        StringBuilder availableRooms = new StringBuilder("🏨 AVAILABLE ROOMS:\n\n");
        int availableCount = 0;
        
        for (Room room : rooms) {
            if ("Available".equals(room.getStatus())) {
                availableRooms.append("• Room ").append(room.getRoomNumber())
                             .append(" - ").append(room.getType())
                             .append(" ($").append(room.getPrice())
                             .append(")\n");
                availableCount++;
            }
        }
        
        if (availableCount == 0) {
            availableRooms.append("❌ No rooms available at the moment.");
        } else {
            availableRooms.append("\nTotal Available: ").append(availableCount).append(" rooms");
        }
        
        JOptionPane.showMessageDialog(this, availableRooms.toString(), 
                                    "Available Rooms", JOptionPane.INFORMATION_MESSAGE);
    }

    private void addRoom() {
        // Simple add room dialog
        JTextField roomField = new JTextField();
        JComboBox<String> typeCombo = new JComboBox<>(new String[]{"Standard", "Deluxe", "Suite", "Premium", "Luxury"});
        JTextField priceField = new JTextField();
        JTextField amenitiesField = new JTextField();

        Object[] message = {
            "Room Number:", roomField,
            "Room Type:", typeCombo,
            "Price per night:", priceField,
            "Amenities:", amenitiesField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add New Room", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int roomNumber = Integer.parseInt(roomField.getText());
                String type = (String) typeCombo.getSelectedItem();
                double price = Double.parseDouble(priceField.getText());
                String amenities = amenitiesField.getText();

                rooms.add(new Room(roomNumber, type, price, amenities, "Available"));
                refreshRoomTable();
                JOptionPane.showMessageDialog(this, "Room added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateRoom() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a room to update!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // FIXED: Safely get room number
        Object roomNumberObj = tableModel.getValueAt(selectedRow, 0);
        if (roomNumberObj == null) {
            JOptionPane.showMessageDialog(this, "Invalid room selection!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int roomNumber = Integer.parseInt(roomNumberObj.toString());
        Room roomToUpdate = null;

        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                roomToUpdate = room;
                break;
            }
        }

        if (roomToUpdate != null) {
            JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Available", "Occupied", "Maintenance"});
            statusCombo.setSelectedItem(roomToUpdate.getStatus());

            Object[] message = {
                "Update Room Status:", statusCombo
            };

            int option = JOptionPane.showConfirmDialog(this, message, "Update Room Status", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                roomToUpdate.setStatus((String) statusCombo.getSelectedItem());
                refreshRoomTable();
                JOptionPane.showMessageDialog(this, "Room status updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void deleteRoom() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a room to delete!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // FIXED: Safely get room number
        Object roomNumberObj = tableModel.getValueAt(selectedRow, 0);
        if (roomNumberObj == null) {
            JOptionPane.showMessageDialog(this, "Invalid room selection!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int roomNumber = Integer.parseInt(roomNumberObj.toString());
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete room " + roomNumber + "?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            rooms.removeIf(room -> room.getRoomNumber() == roomNumber);
            refreshRoomTable();
            JOptionPane.showMessageDialog(this, "Room deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}