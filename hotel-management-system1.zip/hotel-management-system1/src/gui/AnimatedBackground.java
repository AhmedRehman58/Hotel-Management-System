// src/gui/AnimatedBackground.java
package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AnimatedBackground extends JPanel {
    private List<FloatingShape> shapes;
    private Timer timer;
    private Color[] colors = {
        new Color(255, 107, 107, 100),
        new Color(255, 206, 107, 100),
        new Color(107, 255, 167, 100),
        new Color(107, 203, 255, 100),
        new Color(197, 107, 255, 100)
    };

    public AnimatedBackground() {
        shapes = new ArrayList<>();
        Random random = new Random();
        
        // Create floating shapes
        for (int i = 0; i < 15; i++) {
            shapes.add(new FloatingShape(
                random.nextInt(800),
                random.nextInt(600),
                random.nextInt(50) + 20,
                colors[random.nextInt(colors.length)],
                random.nextDouble() * 2 - 1,
                random.nextDouble() * 2 - 1
            ));
        }
        
        // Animation timer
        timer = new Timer(30, e -> {
            for (FloatingShape shape : shapes) {
                shape.update();
            }
            repaint();
        });
        timer.start();
        
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        
        // Enable anti-aliasing for smooth shapes
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw floating shapes
        for (FloatingShape shape : shapes) {
            shape.draw(g2d);
        }
        
        g2d.dispose();
    }

    private class FloatingShape {
        double x, y;
        double size;
        Color color;
        double dx, dy;

        public FloatingShape(double x, double y, double size, Color color, double dx, double dy) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.color = color;
            this.dx = dx;
            this.dy = dy;
        }

        public void update() {
            x += dx;
            y += dy;
            
            // Bounce off walls
            if (x < 0 || x > getWidth()) dx = -dx;
            if (y < 0 || y > getHeight()) dy = -dy;
        }

        public void draw(Graphics2D g2d) {
            g2d.setColor(color);
            
            // Draw 3D-like circles with gradient
            GradientPaint gradient = new GradientPaint(
                (float) x, (float) y, color.brighter(),
                (float) (x + size), (float) (y + size), color.darker(),
                true
            );
            g2d.setPaint(gradient);
            
            Ellipse2D circle = new Ellipse2D.Double(x, y, size, size);
            g2d.fill(circle);
            
            // Add highlight for 3D effect
            g2d.setColor(new Color(255, 255, 255, 80));
            Ellipse2D highlight = new Ellipse2D.Double(x + size * 0.2, y + size * 0.2, size * 0.3, size * 0.3);
            g2d.fill(highlight);
        }
    }
}