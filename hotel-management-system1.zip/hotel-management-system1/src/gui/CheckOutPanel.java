package gui;

import data.HotelQueue;
import gui.styles.Colors;
import models.Guest;

import javax.swing.*;
import java.awt.*;
import java.util.Queue;

public class CheckOutPanel extends JPanel {
    private HotelQueue hotelQueue;
    private JTextArea queueArea;
    private JTextArea statusArea;

    public CheckOutPanel(HotelQueue hotelQueue) {
        this.hotelQueue = hotelQueue;
        initializePanel();
        refreshQueueDisplay();
    }

    private void initializePanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Colors.BACKGROUND_COLOR);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Colors.ACCENT_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("🚪 Guest Check-Out (Dequeue)");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Main Content
        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 20, 20));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Colors.BACKGROUND_COLOR);

        // Queue Display Panel
        mainPanel.add(createQueuePanel());

        // Operations Panel
        mainPanel.add(createOperationsPanel());

        add(mainPanel, BorderLayout.CENTER);

        // Status Panel
        add(createStatusPanel(), BorderLayout.SOUTH);
    }

    private JPanel createQueuePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Colors.CARD_COLOR);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            "Current Check-Out Queue (FIFO)"
        ));

        queueArea = new JTextArea(15, 30);
        queueArea.setEditable(false);
        queueArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        queueArea.setBackground(new Color(250, 250, 250));

        JScrollPane scrollPane = new JScrollPane(queueArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createOperationsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Colors.CARD_COLOR);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            "Queue Operations"
        ));

        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Colors.CARD_COLOR);

        JButton peekBtn = createOperationButton("👀 Peek Next Guest", Colors.SECONDARY_COLOR);
        peekBtn.addActionListener(e -> peekNextGuest());

        JButton dequeueBtn = createOperationButton("✅ Check-Out + Generate Bill", Colors.ACCENT_COLOR);
        dequeueBtn.addActionListener(e -> checkOutGuest());

        JButton deleteBtn = createOperationButton("🗑️ Remove Specific Guest", new Color(255, 87, 34));
        deleteBtn.addActionListener(e -> deleteSpecificGuest());

        JButton refreshBtn = createOperationButton("🔄 Refresh Queue", Colors.WARNING_COLOR);
        refreshBtn.addActionListener(e -> refreshQueueDisplay());

        JButton clearQueueBtn = createOperationButton("🗑️ Clear All", new Color(149, 165, 166));
        clearQueueBtn.addActionListener(e -> clearQueue());

        buttonPanel.add(peekBtn);
        buttonPanel.add(dequeueBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(refreshBtn);
        buttonPanel.add(clearQueueBtn);

        panel.add(buttonPanel, BorderLayout.CENTER);
        return panel;
    }

    private JButton createOperationButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        JLabel statusLabel = new JLabel("Operation Status:");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        statusLabel.setForeground(Colors.TEXT_COLOR);

        statusArea = new JTextArea(3, 50);
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusArea.setBackground(new Color(240, 240, 240));
        statusArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));

        panel.add(statusLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(statusArea), BorderLayout.CENTER);

        return panel;
    }

    private void refreshQueueDisplay() {
        StringBuilder sb = new StringBuilder();
        Queue<Guest> guests = hotelQueue.getAllGuests();
        
        if (guests.isEmpty()) {
            sb.append("No guests in the queue.\nAll rooms are available.");
        } else {
            sb.append("Next guest to check-out is at the TOP:\n\n");
            int position = 1;
            for (Guest guest : guests) {
                sb.append(position).append(". ").append(guest.toString()).append("\n\n");
                position++;
            }
            sb.append("Total guests in queue: ").append(hotelQueue.getQueueSize());
        }
        
        queueArea.setText(sb.toString());
    }

    private void peekNextGuest() {
        Guest nextGuest = hotelQueue.peek();
        if (nextGuest != null) {
            String message = String.format(
                "Next Guest for Check-Out:\n\n" +
                "ID: %d\nName: %s\nRoom: %d\nCheck-In: %s\nCheck-Out: %s\n\n" +
                "Ready for check-out processing...",
                nextGuest.getGuestId(), nextGuest.getName(), nextGuest.getRoomNumber(),
                nextGuest.getCheckInDate(), nextGuest.getCheckOutDate()
            );
            showStatus("👀 Peeked at next guest: " + nextGuest.getName(), Colors.SECONDARY_COLOR);
            JOptionPane.showMessageDialog(this, message, "Next Guest Preview", JOptionPane.INFORMATION_MESSAGE);
        } else {
            showStatus("❌ No guests in queue!", Colors.ACCENT_COLOR);
        }
    }

    private void generateBill(Guest guest) {
        int daysStayed = 3;
        double roomRate = 0.0;
        
        if (guest.getRoomNumber() >= 101 && guest.getRoomNumber() <= 105) {
            roomRate = 99.99;
        } else if (guest.getRoomNumber() >= 106 && guest.getRoomNumber() <= 109) {
            roomRate = 149.99;
        } else {
            roomRate = 199.99;
        }
        
        double roomCharge = daysStayed * roomRate;
        double tax = roomCharge * 0.18;
        double serviceCharge = 50.00;
        double total = roomCharge + tax + serviceCharge;
        
        String bill = String.format(
            "🏨 GRAND HOTEL - OFFICIAL RECEIPT\n" +
            "================================\n" +
            "Guest Details:\n" +
            "  Name: %s\n" +
            "  Room No: %d\n" +
            "  Check-in: %s\n" +
            "  Check-out: %s\n" +
            "  Days Stayed: %d\n" +
            "\n" +
            "Bill Breakdown:\n" +
            "  Room Charge (%d days @ $%.2f): $%.2f\n" +
            "  Service Charge: $%.2f\n" +
            "  GST (18%%): $%.2f\n" +
            "  ---------------------------------\n" +
            "  TOTAL AMOUNT: $%.2f\n" +
            "================================\n" +
            "Thank you for choosing Grand Hotel!\n" +
            "We hope to see you again soon! 🌟",
            guest.getName(), guest.getRoomNumber(),
            guest.getCheckInDate(), java.time.LocalDate.now().toString(),
            daysStayed, daysStayed, roomRate, roomCharge,
            serviceCharge, tax, total
        );
        
        JTextArea billArea = new JTextArea(bill, 20, 45);
        billArea.setEditable(false);
        billArea.setFont(new Font("Courier New", Font.BOLD, 12));
        billArea.setBackground(new Color(255, 255, 240));
        
        JOptionPane.showMessageDialog(this, new JScrollPane(billArea), 
            "💰 BILL RECEIPT - " + guest.getName(), JOptionPane.INFORMATION_MESSAGE);
    }

    private void checkOutGuest() {
        Guest checkedOutGuest = hotelQueue.dequeue();
        if (checkedOutGuest != null) {
            generateBill(checkedOutGuest);
            
            String message = String.format(
                "Guest Checked-Out Successfully!\n\n" +
                "ID: %d\nName: %s\nRoom: %d\n\n" +
                "✅ Bill generated and presented\n" +
                "✅ Room %d is now available\n" +
                "✅ Guest data processed",
                checkedOutGuest.getGuestId(), checkedOutGuest.getName(), 
                checkedOutGuest.getRoomNumber(), checkedOutGuest.getRoomNumber()
            );
            
            showStatus("✅ Checked-out + Bill generated for: " + checkedOutGuest.getName(), Colors.SUCCESS_COLOR);
            JOptionPane.showMessageDialog(this, message, "Check-Out Successful", JOptionPane.INFORMATION_MESSAGE);
            refreshQueueDisplay();
        } else {
            showStatus("❌ No guests to check-out!", Colors.ACCENT_COLOR);
        }
    }

    private void deleteSpecificGuest() {
        String guestIdInput = JOptionPane.showInputDialog(this, 
            "Enter Guest ID to remove from queue:", "Remove Guest", JOptionPane.QUESTION_MESSAGE);
        
        if (guestIdInput != null && !guestIdInput.trim().isEmpty()) {
            try {
                int guestId = Integer.parseInt(guestIdInput.trim());
                Guest guestToDelete = hotelQueue.searchGuest(guestId);
                
                if (guestToDelete != null) {
                    int confirm = JOptionPane.showConfirmDialog(this,
                        "Are you sure you want to remove:\n" +
                        "Guest: " + guestToDelete.getName() + "\n" +
                        "Room: " + guestToDelete.getRoomNumber() + "\n" +
                        "This will cancel their booking!",
                        "Confirm Removal", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        if (hotelQueue.deleteGuest(guestId)) {
                            showStatus("🗑️ Guest ID " + guestId + " removed from queue!", Colors.ACCENT_COLOR);
                            refreshQueueDisplay();
                        } else {
                            showStatus("❌ Failed to remove guest!", Colors.ACCENT_COLOR);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Guest with ID " + guestId + " not found!", 
                        "Not Found", JOptionPane.WARNING_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid Guest ID number!", 
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearQueue() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to clear all guests from the queue?\nThis will check-out ALL guests!",
            "Confirm Clear Queue",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            while (!hotelQueue.isEmpty()) {
                hotelQueue.dequeue();
            }
            showStatus("🗑️ All guests checked-out. Queue cleared!", Colors.WARNING_COLOR);
            refreshQueueDisplay();
        }
    }

    private void showStatus(String message, Color color) {
        statusArea.setForeground(color);
        statusArea.setText(message);
    }
}