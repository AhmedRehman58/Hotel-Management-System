package gui;

import data.HotelQueue;
import gui.styles.Colors;
import models.Guest;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Queue;

public class DashboardPanel extends JPanel {
    private HotelQueue hotelQueue;
    private JTable guestTable;
    private DefaultTableModel tableModel;
    private JLabel totalGuestsLabel, checkedInLabel, availableRoomsLabel, revenueLabel;
    private JTextField searchField;

    public DashboardPanel(HotelQueue hotelQueue) {
        this.hotelQueue = hotelQueue;
        initializePanel();
        refreshDashboard();
    }

    private void initializePanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Colors.BACKGROUND_COLOR);

        // Header
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Stats Panel
        JPanel statsPanel = createStatsPanel();
        add(statsPanel, BorderLayout.CENTER);

        // Guest Table
        JPanel tablePanel = createTablePanel();
        add(tablePanel, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        // 🆕 FIX: Colors.PRIMARY_COLOR use karo
        panel.setBackground(Colors.PRIMARY_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        JLabel titleLabel = new JLabel("🏨 LUXURY HOTEL DASHBOARD");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("Real-time Queue Management System");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(220, 220, 220));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Colors.PRIMARY_COLOR); // 🆕 FIX
        titlePanel.add(titleLabel, BorderLayout.WEST);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);

        // Quick stats
        JPanel quickStats = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        quickStats.setBackground(Colors.PRIMARY_COLOR); // 🆕 FIX
        
        JLabel timeLabel = new JLabel("🕒 " + new java.util.Date().toString());
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        timeLabel.setForeground(Color.WHITE);
        quickStats.add(timeLabel);

        panel.add(titlePanel, BorderLayout.WEST);
        panel.add(quickStats, BorderLayout.EAST);

        return panel;
    }

    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        // Total Guests Card
        JPanel totalCard = createModernStatCard("👥 TOTAL GUESTS", "0", Colors.PRIMARY_COLOR, "Currently in hotel");
        totalGuestsLabel = (JLabel) ((JPanel) totalCard.getComponent(1)).getComponent(0);

        // Checked-In Card
        JPanel checkedInCard = createModernStatCard("✅ CHECKED-IN", "0", Colors.SUCCESS_COLOR, "Active guests");
        checkedInLabel = (JLabel) ((JPanel) checkedInCard.getComponent(1)).getComponent(0);

        // Available Rooms Card
        JPanel roomsCard = createModernStatCard("🛏️ AVAILABLE ROOMS", "15", Colors.WARNING_COLOR, "Ready for check-in");
        availableRoomsLabel = (JLabel) ((JPanel) roomsCard.getComponent(1)).getComponent(0);

        // Revenue Card
        JPanel revenueCard = createModernStatCard("💰 DAILY REVENUE", "₹0", new Color(155, 89, 182), "Today's earnings");
        revenueLabel = (JLabel) ((JPanel) revenueCard.getComponent(1)).getComponent(0);

        panel.add(totalCard);
        panel.add(checkedInCard);
        panel.add(roomsCard);
        panel.add(revenueCard);

        return panel;
    }

    private JPanel createModernStatCard(String title, String value, Color color, String subtitle) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Colors.CARD_COLOR);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 3),
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));

        // Title and subtitle
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Colors.CARD_COLOR);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Colors.TEXT_COLOR);
        
        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(Color.GRAY);
        
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);

        // Value with icon
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        valueLabel.setForeground(color);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel valuePanel = new JPanel(new BorderLayout());
        valuePanel.setBackground(Colors.CARD_COLOR);
        valuePanel.add(valueLabel, BorderLayout.CENTER);

        card.add(titlePanel, BorderLayout.NORTH);
        card.add(valuePanel, BorderLayout.CENTER);

        return card;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 25, 25, 25));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        // Table header with search
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Colors.BACKGROUND_COLOR);
        
        JLabel tableTitle = new JLabel("CURRENT GUESTS QUEUE (FIFO ORDER)");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        tableTitle.setForeground(Colors.TEXT_COLOR);
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        searchPanel.setBackground(Colors.BACKGROUND_COLOR);
        
        searchPanel.add(new JLabel("🔍 SEARCH:"));
        searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        searchPanel.add(searchField);
        
        JButton searchBtn = new JButton("Search");
        searchBtn.setBackground(Colors.PRIMARY_COLOR);
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        searchBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        searchBtn.addActionListener(e -> searchGuests());
        searchPanel.add(searchBtn);
        
        JButton clearSearchBtn = new JButton("Clear");
        clearSearchBtn.setBackground(Colors.ACCENT_COLOR);
        clearSearchBtn.setForeground(Color.WHITE);
        clearSearchBtn.addActionListener(e -> {
            searchField.setText("");
            refreshDashboard();
        });
        searchPanel.add(clearSearchBtn);

        headerPanel.add(tableTitle, BorderLayout.WEST);
        headerPanel.add(searchPanel, BorderLayout.EAST);

        // Table setup
        String[] columns = {"GUEST ID", "NAME", "EMAIL", "PHONE", "ID PROOF", "ROOM NO", "CHECK-IN", "CHECK-OUT", "STATUS"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        guestTable = new JTable(tableModel);
        guestTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        guestTable.setRowHeight(35);
        guestTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        guestTable.getTableHeader().setBackground(Colors.PRIMARY_COLOR);
        guestTable.getTableHeader().setForeground(Color.WHITE);
        guestTable.setSelectionBackground(Colors.SECONDARY_COLOR);

        JScrollPane scrollPane = new JScrollPane(guestTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(Colors.PRIMARY_COLOR, 2));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Refresh button
        JButton refreshBtn = new JButton("🔄 REFRESH DASHBOARD");
        refreshBtn.setBackground(Colors.SUCCESS_COLOR);
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        refreshBtn.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        refreshBtn.addActionListener(e -> refreshDashboard());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Colors.BACKGROUND_COLOR);
        buttonPanel.add(refreshBtn);

        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void searchGuests() {
        String searchText = searchField.getText().trim();
        
        if (searchText.isEmpty()) {
            refreshDashboard();
            return;
        }
        
        tableModel.setRowCount(0);
        Queue<Guest> guests = hotelQueue.getAllGuests();
        boolean found = false;
        
        for (Guest guest : guests) {
            if (guest.getName().toLowerCase().contains(searchText.toLowerCase()) ||
                guest.getEmail().toLowerCase().contains(searchText.toLowerCase()) ||
                String.valueOf(guest.getRoomNumber()).contains(searchText) ||
                guest.getPhone().contains(searchText)) {
                
                tableModel.addRow(guest.toTableRow());
                found = true;
            }
        }
        
        if (!found) {
            JOptionPane.showMessageDialog(this, 
                "No guests found matching: '" + searchText + "'", 
                "Search Results", 
                JOptionPane.INFORMATION_MESSAGE);
            refreshDashboard();
        }
    }

    public void refreshDashboard() {
        // Update stats
        int totalGuests = hotelQueue.getQueueSize();
        int checkedInGuests = hotelQueue.getGuestsByStatus("Checked-In").size();
        
        totalGuestsLabel.setText(String.valueOf(totalGuests));
        checkedInLabel.setText(String.valueOf(checkedInGuests));
        availableRoomsLabel.setText(String.valueOf(50 - checkedInGuests));
        
        // Revenue calculation - ₹2500 per guest
        double totalRevenue = totalGuests * 2500;
        revenueLabel.setText("₹" + (int)totalRevenue);

        // Update table
        tableModel.setRowCount(0);
        Queue<Guest> guests = hotelQueue.getAllGuests();
        
        for (Guest guest : guests) {
            tableModel.addRow(guest.toTableRow());
        }
    }
}