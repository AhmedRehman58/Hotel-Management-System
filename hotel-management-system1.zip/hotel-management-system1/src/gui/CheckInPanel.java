package gui;

import data.HotelQueue;
import gui.styles.Colors;
import models.Guest;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Queue;

public class CheckInPanel extends JPanel {
    private HotelQueue hotelQueue;
    private JTextField nameField, emailField, phoneField, idProofField;
    private JFormattedTextField checkInField, checkOutField;
    private JTextArea statusArea;
    private JComboBox<String> roomComboBox; // ROOM COMBOBOX

    public CheckInPanel(HotelQueue hotelQueue) {
        this.hotelQueue = hotelQueue;
        initializePanel();
    }

    private void initializePanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Colors.BACKGROUND_COLOR);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Colors.SUCCESS_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("✅ Guest Check-In (Enqueue)");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);

        // Status Panel
        JPanel statusPanel = createStatusPanel();
        add(statusPanel, BorderLayout.SOUTH);
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Colors.CARD_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Name Field
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        nameField = createTextField();
        panel.add(nameField, gbc);

        // Email Field
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = createTextField();
        panel.add(emailField, gbc);

        // Phone Field
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createLabel("Phone:"), gbc);
        gbc.gridx = 1;
        phoneField = createTextField();
        panel.add(phoneField, gbc);

        // ID Proof Field
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(createLabel("ID Proof:"), gbc);
        gbc.gridx = 1;
        idProofField = createTextField();
        panel.add(idProofField, gbc);

        // ROOM SELECTION COMBOBOX
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(createLabel("Select Room:"), gbc);
        gbc.gridx = 1;
        roomComboBox = new JComboBox<>(getAvailableRooms());
        roomComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        roomComboBox.setBackground(Color.WHITE);
        panel.add(roomComboBox, gbc);

        // Check-in Date
        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(createLabel("Check-in Date:"), gbc);
        gbc.gridx = 1;
        checkInField = createDateField();
        panel.add(checkInField, gbc);

        // Check-out Date
        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(createLabel("Check-out Date:"), gbc);
        gbc.gridx = 1;
        checkOutField = createDateField();
        panel.add(checkOutField, gbc);

        // Buttons
        gbc.gridx = 0; gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Colors.CARD_COLOR);

        JButton checkInBtn = createButton("Check-In Guest", Colors.SUCCESS_COLOR);
        checkInBtn.addActionListener(e -> checkInGuest());

        JButton clearBtn = createButton("Clear Form", Colors.WARNING_COLOR);
        clearBtn.addActionListener(e -> clearForm());

        // REFRESH ROOMS BUTTON
        JButton refreshRoomsBtn = createButton("🔄 Refresh Rooms", Colors.SECONDARY_COLOR);
        refreshRoomsBtn.addActionListener(e -> refreshAvailableRooms());

        buttonPanel.add(checkInBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(refreshRoomsBtn);

        panel.add(buttonPanel, gbc);

        return panel;
    }

    // GET AVAILABLE ROOMS METHOD
    private String[] getAvailableRooms() {
        // All available rooms
        String[] allRooms = {"101 - Standard ($99)", "102 - Standard ($99)", "103 - Standard ($99)", 
                            "104 - Deluxe ($149)", "105 - Deluxe ($149)", "106 - Suite ($199)", 
                            "107 - Suite ($199)", "108 - Premium ($249)", "109 - Premium ($249)", 
                            "110 - Luxury ($299)"};
        
        // Get occupied rooms from queue
        Queue<Guest> guests = hotelQueue.getAllGuests();
        java.util.List<String> availableRooms = new java.util.ArrayList<>();
        
        // Add all rooms initially
        for (String room : allRooms) {
            availableRooms.add(room);
        }
        
        // Remove occupied rooms
        for (Guest guest : guests) {
            int occupiedRoom = guest.getRoomNumber();
            availableRooms.removeIf(room -> room.startsWith(occupiedRoom + " -"));
        }
        
        // If no rooms available, show message
        if (availableRooms.isEmpty()) {
            return new String[]{"No rooms available"};
        }
        
        return availableRooms.toArray(new String[0]);
    }

    // REFRESH AVAILABLE ROOMS METHOD
    private void refreshAvailableRooms() {
        roomComboBox.setModel(new DefaultComboBoxModel<>(getAvailableRooms()));
        showStatus("🔄 Available rooms list updated!", Colors.SECONDARY_COLOR);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(Colors.TEXT_COLOR);
        return label;
    }

    private JTextField createTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        return field;
    }

    private JFormattedTextField createDateField() {
        JFormattedTextField field = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
        field.setValue(new Date());
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        return field;
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        panel.setBackground(Colors.BACKGROUND_COLOR);

        JLabel statusLabel = new JLabel("Operation Status:");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        statusLabel.setForeground(Colors.TEXT_COLOR);

        statusArea = new JTextArea(3, 50);
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusArea.setBackground(new Color(240, 240, 240));
        statusArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.PRIMARY_COLOR),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));

        panel.add(statusLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(statusArea), BorderLayout.CENTER);

        return panel;
    }

    private void checkInGuest() {
        try {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String idProof = idProofField.getText().trim();
            Object selectedRoomObj = roomComboBox.getSelectedItem();
            String checkInDate = checkInField.getText();
            String checkOutDate = checkOutField.getText();

            // Validation
            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || idProof.isEmpty()) {
                showStatus("Please fill all fields!", Colors.ACCENT_COLOR);
                return;
            }

            if (selectedRoomObj == null || selectedRoomObj.toString().equals("No rooms available")) {
                showStatus("❌ No rooms available for check-in!", Colors.ACCENT_COLOR);
                return;
            }

            // EXTRACT ROOM NUMBER FROM SELECTED ROOM
            String selectedRoom = selectedRoomObj.toString();
            int roomNumber = Integer.parseInt(selectedRoom.split(" -")[0]);

            // Enqueue operation
            if (hotelQueue.enqueue(name, email, phone, idProof, roomNumber, checkInDate, checkOutDate)) {
                showStatus("✅ Guest '" + name + "' checked-in successfully! Room: " + roomNumber, Colors.SUCCESS_COLOR);
                clearForm();
                refreshAvailableRooms(); // UPDATE ROOMS LIST AFTER CHECK-IN
            } else {
                showStatus("❌ Failed to check-in guest!", Colors.ACCENT_COLOR);
            }

        } catch (Exception e) {
            showStatus("❌ Error: " + e.getMessage(), Colors.ACCENT_COLOR);
        }
    }

    private void clearForm() {
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        idProofField.setText("");
        checkInField.setValue(new Date());
        checkOutField.setValue(new Date());
    }

    private void showStatus(String message, Color color) {
        statusArea.setForeground(color);
        statusArea.setText(message);
    }
}