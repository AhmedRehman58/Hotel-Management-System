package models;

public class Guest {
    private int guestId;
    private String name;
    private String email;
    private String phone;
    private String idProof;
    private int roomNumber;
    private String checkInDate;
    private String checkOutDate;
    private String status;

    public Guest(int guestId, String name, String email, String phone, String idProof, 
                 int roomNumber, String checkInDate, String checkOutDate, String status) {
        this.guestId = guestId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.idProof = idProof;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.status = status;
    }

    public int getGuestId() { return guestId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getIdProof() { return idProof; }
    public int getRoomNumber() { return roomNumber; }
    public String getCheckInDate() { return checkInDate; }
    public String getCheckOutDate() { return checkOutDate; }
    public String getStatus() { return status; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setIdProof(String idProof) { this.idProof = idProof; }
    public void setRoomNumber(int roomNumber) { this.roomNumber = roomNumber; }
    public void setCheckInDate(String checkInDate) { this.checkInDate = checkInDate; }
    public void setCheckOutDate(String checkOutDate) { this.checkOutDate = checkOutDate; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("ID: %-3d | Name: %-15s | Room: %-3d | Status: %-12s | Check-In: %s",
                guestId, name, roomNumber, status, checkInDate);
    }

    public String[] toTableRow() {
        return new String[]{
            String.valueOf(guestId),
            name,
            email,
            phone,
            idProof,
            String.valueOf(roomNumber),
            checkInDate,
            checkOutDate,
            status
        };
    }
}