import gui.MainFrame;

public class Main {
    public static void main(String[] args) {
        MainFrame.main(args);
    }
}